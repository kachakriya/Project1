Laravel + Mysql + Authentication
====================================================




Preparation
------------
```
composer install
```

Starting application
--------------------
```
php artisan serve
```


[referance](https://www.positronx.io/)
